# Changelog

## 0.1.0

Initial contract-first package for Conexus v1.

Includes:

- OpenAPI contract
- JSON schemas
- ADRs
- architecture notes
- PR backlog
- Cursor/Codex implementation prompts
- .NET typed client skeleton
- Python FastAPI skeleton
- examples
- contract test skeleton
