namespace Conexus.Client;

public interface IConexusClient
{
    Task<HealthResponse> GetHealthAsync(CancellationToken cancellationToken = default);

    Task<ModelListResponse> ListModelsAsync(CancellationToken cancellationToken = default);

    Task<RouteDecision> RouteAsync(
        RouteRequest request,
        CancellationToken cancellationToken = default);

    Task<ChatCompletionResponse> CompleteAsync(
        ChatCompletionRequest request,
        CancellationToken cancellationToken = default);

    Task<EmbeddingResponse> EmbedAsync(
        EmbeddingRequest request,
        CancellationToken cancellationToken = default);

    Task<UsageEvent> GetUsageAsync(
        string traceId,
        CancellationToken cancellationToken = default);

    Task<TraceEvent> GetTraceAsync(
        string traceId,
        CancellationToken cancellationToken = default);
}
