namespace Conexus.Client;

public sealed record HealthResponse(
    string Status,
    string Service,
    string Version);

public sealed record CallerContext(
    string System,
    string? Component = null,
    string? Operation = null,
    string? UserId = null,
    string? TenantId = null);

public sealed record RoutePreferences(
    string Cost = "balanced",
    string Latency = "balanced",
    string Quality = "balanced");

public sealed record ConexusMessage(
    string Role,
    string Content,
    string? Name = null,
    string? ToolCallId = null);

public sealed record ResponseFormat(
    string Type = "text",
    Dictionary<string, object?>? JsonSchema = null);

public sealed record ChatCompletionRequest(
    IReadOnlyList<ConexusMessage> Messages,
    CallerContext Caller,
    string? TraceId = null,
    string? ModelAlias = null,
    string? Model = null,
    string TaskType = "general_chat",
    double Temperature = 0.2,
    int? MaxOutputTokens = null,
    ResponseFormat? ResponseFormat = null,
    IReadOnlyList<string>? RequiredCapabilities = null,
    RoutePreferences? Preferences = null,
    Dictionary<string, object?>? Metadata = null);

public sealed record ChatCompletionResponse(
    string Id,
    string TraceId,
    string Object,
    DateTimeOffset CreatedAt,
    string Provider,
    string Model,
    string? ModelAlias,
    IReadOnlyList<ChatChoice> Choices,
    RouteDecision Route,
    TokenUsage Usage);

public sealed record ChatChoice(
    int Index,
    ConexusMessage Message,
    string FinishReason);

public sealed record EmbeddingRequest(
    object Input,
    CallerContext Caller,
    string? TraceId = null,
    string? ModelAlias = null,
    string? Model = null,
    int? Dimensions = null,
    Dictionary<string, object?>? Metadata = null);

public sealed record EmbeddingResponse(
    string Id,
    string TraceId,
    string Object,
    DateTimeOffset CreatedAt,
    string Provider,
    string Model,
    string? ModelAlias,
    IReadOnlyList<EmbeddingItem> Data,
    RouteDecision Route,
    TokenUsage Usage);

public sealed record EmbeddingItem(
    int Index,
    IReadOnlyList<double> Embedding);

public sealed record RouteRequest(
    string TaskType,
    CallerContext Caller,
    string? TraceId = null,
    string? ModelAlias = null,
    string? Model = null,
    IReadOnlyList<string>? RequiredCapabilities = null,
    RoutePreferences? Preferences = null,
    Dictionary<string, object?>? Metadata = null);

public sealed record RouteDecision(
    string TraceId,
    SelectedModel Selected,
    IReadOnlyList<string> ReasonCodes,
    IReadOnlyList<SelectedModel> FallbackChain,
    string PolicyVersion);

public sealed record SelectedModel(
    string Provider,
    string Model,
    string? ModelAlias = null);

public sealed record ModelListResponse(
    IReadOnlyList<ModelDescriptor> Models);

public sealed record ModelDescriptor(
    string Provider,
    string Model,
    IReadOnlyList<string> ModelAliases,
    IReadOnlyList<string> Capabilities,
    int? ContextWindow,
    bool Enabled);

public sealed record TokenUsage(
    int InputTokens,
    int OutputTokens,
    int TotalTokens);

public sealed record CostEstimate(
    string Currency,
    decimal Estimated);

public sealed record UsageEvent(
    string TraceId,
    DateTimeOffset Timestamp,
    CallerContext Caller,
    string Provider,
    string Model,
    string? ModelAlias,
    TokenUsage Usage,
    CostEstimate Cost,
    int LatencyMs,
    string Status);

public sealed record TraceEvent(
    string TraceId,
    DateTimeOffset StartedAt,
    DateTimeOffset? EndedAt,
    CallerContext Caller,
    RouteDecision Route,
    IReadOnlyList<TraceStep> Events,
    string Status);

public sealed record TraceStep(
    DateTimeOffset Timestamp,
    string Name,
    Dictionary<string, object?>? Data = null);
