using System.Net.Http.Json;
using System.Text.Json;

namespace Conexus.Client;

public sealed class ConexusClient : IConexusClient
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    private readonly HttpClient _httpClient;

    public ConexusClient(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public Task<HealthResponse> GetHealthAsync(CancellationToken cancellationToken = default)
        => GetAsync<HealthResponse>("/health", cancellationToken);

    public Task<ModelListResponse> ListModelsAsync(CancellationToken cancellationToken = default)
        => GetAsync<ModelListResponse>("/v1/models", cancellationToken);

    public Task<RouteDecision> RouteAsync(RouteRequest request, CancellationToken cancellationToken = default)
        => PostAsync<RouteRequest, RouteDecision>("/v1/route", request, cancellationToken);

    public Task<ChatCompletionResponse> CompleteAsync(ChatCompletionRequest request, CancellationToken cancellationToken = default)
        => PostAsync<ChatCompletionRequest, ChatCompletionResponse>("/v1/chat/completions", request, cancellationToken);

    public Task<EmbeddingResponse> EmbedAsync(EmbeddingRequest request, CancellationToken cancellationToken = default)
        => PostAsync<EmbeddingRequest, EmbeddingResponse>("/v1/embeddings", request, cancellationToken);

    public Task<UsageEvent> GetUsageAsync(string traceId, CancellationToken cancellationToken = default)
        => GetAsync<UsageEvent>($"/v1/usage/{Uri.EscapeDataString(traceId)}", cancellationToken);

    public Task<TraceEvent> GetTraceAsync(string traceId, CancellationToken cancellationToken = default)
        => GetAsync<TraceEvent>($"/v1/traces/{Uri.EscapeDataString(traceId)}", cancellationToken);

    private async Task<T> GetAsync<T>(string path, CancellationToken cancellationToken)
    {
        using var response = await _httpClient.GetAsync(path, cancellationToken).ConfigureAwait(false);
        return await ReadOrThrowAsync<T>(response, cancellationToken).ConfigureAwait(false);
    }

    private async Task<TResponse> PostAsync<TRequest, TResponse>(
        string path,
        TRequest request,
        CancellationToken cancellationToken)
    {
        using var response = await _httpClient.PostAsJsonAsync(path, request, JsonOptions, cancellationToken).ConfigureAwait(false);
        return await ReadOrThrowAsync<TResponse>(response, cancellationToken).ConfigureAwait(false);
    }

    private static async Task<T> ReadOrThrowAsync<T>(HttpResponseMessage response, CancellationToken cancellationToken)
    {
        if (response.IsSuccessStatusCode)
        {
            var value = await response.Content.ReadFromJsonAsync<T>(JsonOptions, cancellationToken).ConfigureAwait(false);
            return value ?? throw new ConexusClientException("Conexus returned an empty response body.");
        }

        string body = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
        throw new ConexusClientException(
            $"Conexus request failed with status {(int)response.StatusCode} {response.ReasonPhrase}. Body: {body}",
            (int)response.StatusCode,
            body);
    }
}

public sealed class ConexusClientException : Exception
{
    public int? StatusCode { get; }
    public string? ResponseBody { get; }

    public ConexusClientException(string message, int? statusCode = null, string? responseBody = null)
        : base(message)
    {
        StatusCode = statusCode;
        ResponseBody = responseBody;
    }
}
