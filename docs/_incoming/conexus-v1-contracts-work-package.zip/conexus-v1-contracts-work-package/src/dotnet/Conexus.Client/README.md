# Conexus.Client

Typed .NET client for Conexus.

## Registration

```csharp
builder.Services.AddConexusClient(options =>
{
    options.BaseUrl = builder.Configuration["Conexus:BaseUrl"]!;
    options.ApiKey = builder.Configuration["Conexus:ApiKey"];
});
```

## Usage

```csharp
public sealed class Planner
{
    private readonly IConexusClient _conexus;

    public Planner(IConexusClient conexus)
    {
        _conexus = conexus;
    }

    public async Task<string> CreatePlanAsync(string goal, CancellationToken ct)
    {
        var response = await _conexus.CompleteAsync(
            new ChatCompletionRequest(
                Messages:
                [
                    new ConexusMessage("system", "You are an agent planner."),
                    new ConexusMessage("user", goal)
                ],
                Caller: new CallerContext(
                    System: "agentor",
                    Component: "planner",
                    Operation: "create_plan"),
                ModelAlias: "strong-reasoning",
                TaskType: "agent_planning"),
            ct);

        return response.Choices[0].Message.Content;
    }
}
```

## Rule

Do not add OpenAI, Anthropic, Gemini, or other provider SDKs to Agentor/Athanor for normal operation. They should depend on this client, not providers.
