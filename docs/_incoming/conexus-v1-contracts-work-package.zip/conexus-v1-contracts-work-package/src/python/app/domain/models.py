from datetime import datetime, timezone
from typing import Any, Literal

from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    status: Literal["ok", "degraded", "unavailable"]
    service: str
    version: str


class CallerContext(BaseModel):
    system: str
    component: str | None = None
    operation: str | None = None
    user_id: str | None = None
    tenant_id: str | None = None


class RoutePreferences(BaseModel):
    cost: Literal["low", "balanced", "high"] = "balanced"
    latency: Literal["low", "balanced", "high"] = "balanced"
    quality: Literal["low", "balanced", "high"] = "balanced"


class ResponseFormat(BaseModel):
    type: Literal["text", "json_object", "json_schema"] = "text"
    json_schema: dict[str, Any] | None = None


class ConexusMessage(BaseModel):
    role: Literal["system", "user", "assistant", "tool"]
    content: str
    name: str | None = None
    tool_call_id: str | None = None


class RouteRequest(BaseModel):
    trace_id: str | None = None
    task_type: str
    model_alias: str | None = None
    model: str | None = None
    required_capabilities: list[str] = Field(default_factory=list)
    preferences: RoutePreferences = Field(default_factory=RoutePreferences)
    caller: CallerContext
    metadata: dict[str, Any] = Field(default_factory=dict)


class ChatCompletionRequest(BaseModel):
    trace_id: str | None = None
    model_alias: str | None = None
    model: str | None = None
    task_type: str = "general_chat"
    messages: list[ConexusMessage]
    temperature: float = 0.2
    max_output_tokens: int | None = None
    response_format: ResponseFormat = Field(default_factory=ResponseFormat)
    required_capabilities: list[str] = Field(default_factory=list)
    preferences: RoutePreferences = Field(default_factory=RoutePreferences)
    caller: CallerContext
    metadata: dict[str, Any] = Field(default_factory=dict)

    def to_route_request(self) -> RouteRequest:
        return RouteRequest(
            trace_id=self.trace_id,
            task_type=self.task_type,
            model_alias=self.model_alias,
            model=self.model,
            required_capabilities=self.required_capabilities,
            preferences=self.preferences,
            caller=self.caller,
            metadata=self.metadata,
        )


class EmbeddingRequest(BaseModel):
    trace_id: str | None = None
    model_alias: str | None = None
    model: str | None = None
    input: str | list[str]
    dimensions: int | None = None
    caller: CallerContext
    metadata: dict[str, Any] = Field(default_factory=dict)

    def to_route_request(self) -> RouteRequest:
        return RouteRequest(
            trace_id=self.trace_id,
            task_type="embedding",
            model_alias=self.model_alias,
            model=self.model,
            required_capabilities=["embedding"],
            caller=self.caller,
            metadata=self.metadata,
        )


class SelectedModel(BaseModel):
    provider: str
    model: str
    model_alias: str | None = None


class RouteDecision(BaseModel):
    trace_id: str
    selected: SelectedModel
    reason_codes: list[str]
    fallback_chain: list[SelectedModel]
    policy_version: str


class ChatChoice(BaseModel):
    index: int
    message: ConexusMessage
    finish_reason: Literal["stop", "length", "tool_calls", "content_filter", "error"]


class TokenUsage(BaseModel):
    input_tokens: int
    output_tokens: int
    total_tokens: int


class ChatCompletionResponse(BaseModel):
    id: str
    trace_id: str
    object: Literal["chat.completion"] = "chat.completion"
    created_at: datetime
    provider: str
    model: str
    model_alias: str | None = None
    choices: list[ChatChoice]
    route: RouteDecision
    usage: TokenUsage


class EmbeddingItem(BaseModel):
    index: int
    embedding: list[float]


class EmbeddingResponse(BaseModel):
    id: str
    trace_id: str
    object: Literal["embedding"] = "embedding"
    created_at: datetime
    provider: str
    model: str
    model_alias: str | None = None
    data: list[EmbeddingItem]
    route: RouteDecision
    usage: TokenUsage


class ModelDescriptor(BaseModel):
    provider: str
    model: str
    model_aliases: list[str] = Field(default_factory=list)
    capabilities: list[str]
    context_window: int | None = None
    enabled: bool


class ModelListResponse(BaseModel):
    models: list[ModelDescriptor]


class CostEstimate(BaseModel):
    currency: str
    estimated: float


class UsageEvent(BaseModel):
    trace_id: str
    timestamp: datetime
    caller: CallerContext
    provider: str
    model: str
    model_alias: str | None = None
    usage: TokenUsage
    cost: CostEstimate
    latency_ms: int
    status: Literal["succeeded", "failed"]


class TraceStep(BaseModel):
    timestamp: datetime
    name: str
    data: dict[str, Any] = Field(default_factory=dict)


class TraceEvent(BaseModel):
    trace_id: str
    started_at: datetime
    ended_at: datetime | None = None
    caller: CallerContext
    route: RouteDecision
    events: list[TraceStep]
    status: Literal["succeeded", "failed", "partial"]


class ConexusError(BaseModel):
    code: str
    message: str
    trace_id: str | None = None
    provider: str | None = None
    retryable: bool = False
    details: dict[str, Any] | None = None


class ErrorEnvelope(BaseModel):
    error: ConexusError
