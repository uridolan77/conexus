from fastapi import FastAPI

from app.api.routes import router

app = FastAPI(
    title="Conexus API",
    version="1.0.0",
    description="LLM router/gateway for Agentor and Athanor.",
)

app.include_router(router)
