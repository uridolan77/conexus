from datetime import datetime, timezone

from app.domain.models import (
    ChatChoice,
    ChatCompletionRequest,
    ChatCompletionResponse,
    ConexusMessage,
    EmbeddingItem,
    EmbeddingRequest,
    EmbeddingResponse,
    ModelDescriptor,
    RouteDecision,
    TokenUsage,
)


class MockProvider:
    name = "mock"

    async def list_models(self) -> list[ModelDescriptor]:
        return [
            ModelDescriptor(
                provider="mock",
                model="mock-fast-general",
                model_aliases=["fast-general"],
                capabilities=["chat"],
                context_window=128000,
                enabled=True,
            ),
            ModelDescriptor(
                provider="mock",
                model="mock-strong-reasoning",
                model_aliases=["strong-reasoning"],
                capabilities=["chat", "reasoning"],
                context_window=128000,
                enabled=True,
            ),
            ModelDescriptor(
                provider="mock",
                model="mock-embedding-general",
                model_aliases=["embedding-general"],
                capabilities=["embedding"],
                context_window=8192,
                enabled=True,
            ),
        ]

    async def chat(
        self,
        request: ChatCompletionRequest,
        trace_id: str,
        route: RouteDecision,
    ) -> ChatCompletionResponse:
        content = "Mock Conexus response. Replace MockProvider with real provider adapters."

        usage = TokenUsage(
            input_tokens=sum(len(message.content.split()) for message in request.messages),
            output_tokens=len(content.split()),
            total_tokens=sum(len(message.content.split()) for message in request.messages) + len(content.split()),
        )

        return ChatCompletionResponse(
            id=f"chatcmpl_{trace_id}",
            trace_id=trace_id,
            created_at=datetime.now(timezone.utc),
            provider=route.selected.provider,
            model=route.selected.model,
            model_alias=route.selected.model_alias,
            choices=[
                ChatChoice(
                    index=0,
                    message=ConexusMessage(role="assistant", content=content),
                    finish_reason="stop",
                )
            ],
            route=route,
            usage=usage,
        )

    async def embed(
        self,
        request: EmbeddingRequest,
        trace_id: str,
        route: RouteDecision,
    ) -> EmbeddingResponse:
        values = request.input if isinstance(request.input, list) else [request.input]

        usage = TokenUsage(
            input_tokens=sum(len(value.split()) for value in values),
            output_tokens=0,
            total_tokens=sum(len(value.split()) for value in values),
        )

        return EmbeddingResponse(
            id=f"emb_{trace_id}",
            trace_id=trace_id,
            created_at=datetime.now(timezone.utc),
            provider=route.selected.provider,
            model=route.selected.model,
            model_alias=route.selected.model_alias,
            data=[
                EmbeddingItem(index=index, embedding=[0.01, 0.02, 0.03])
                for index, _ in enumerate(values)
            ],
            route=route,
            usage=usage,
        )
