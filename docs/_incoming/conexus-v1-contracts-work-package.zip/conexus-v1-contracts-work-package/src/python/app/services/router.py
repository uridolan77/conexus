from app.domain.models import RouteDecision, RouteRequest, SelectedModel


class RoutingService:
    policy_version = "2026-05-11.1"

    def route(self, request: RouteRequest, trace_id: str) -> RouteDecision:
        alias = request.model_alias or self._default_alias_for_task(request.task_type)

        if request.model:
            selected = SelectedModel(
                provider="mock",
                model=request.model,
                model_alias=alias,
            )
            reason_codes = ["explicit_model", "provider_mock"]
        elif alias == "strong-reasoning":
            selected = SelectedModel(
                provider="mock",
                model="mock-strong-reasoning",
                model_alias=alias,
            )
            reason_codes = ["alias_match", "quality_preference_balanced"]
        elif alias == "embedding-general":
            selected = SelectedModel(
                provider="mock",
                model="mock-embedding-general",
                model_alias=alias,
            )
            reason_codes = ["alias_match", "capability_embedding"]
        else:
            selected = SelectedModel(
                provider="mock",
                model="mock-fast-general",
                model_alias=alias,
            )
            reason_codes = ["alias_match", "cost_preference_balanced"]

        fallback_chain = [
            SelectedModel(provider="mock", model="mock-balanced", model_alias="fallback-general")
        ]

        return RouteDecision(
            trace_id=trace_id,
            selected=selected,
            reason_codes=reason_codes,
            fallback_chain=fallback_chain,
            policy_version=self.policy_version,
        )

    @staticmethod
    def _default_alias_for_task(task_type: str) -> str:
        if task_type == "embedding":
            return "embedding-general"
        if task_type in {"agent_planning", "canonicalization", "reasoning"}:
            return "strong-reasoning"
        return "fast-general"
