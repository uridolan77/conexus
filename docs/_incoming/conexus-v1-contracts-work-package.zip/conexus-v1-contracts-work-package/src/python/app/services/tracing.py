from datetime import datetime, timezone
from uuid import uuid4

from fastapi import HTTPException

from app.domain.models import (
    CallerContext,
    CostEstimate,
    RouteDecision,
    TraceEvent,
    TraceStep,
    TokenUsage,
    UsageEvent,
)


def make_trace_id() -> str:
    return f"trc_{uuid4().hex}"


class TraceStore:
    def __init__(self) -> None:
        self._usage: dict[str, UsageEvent] = {}
        self._traces: dict[str, TraceEvent] = {}

    def record_success(
        self,
        trace_id: str,
        caller: CallerContext,
        route: RouteDecision,
        usage: TokenUsage,
    ) -> None:
        now = datetime.now(timezone.utc)

        self._usage[trace_id] = UsageEvent(
            trace_id=trace_id,
            timestamp=now,
            caller=caller,
            provider=route.selected.provider,
            model=route.selected.model,
            model_alias=route.selected.model_alias,
            usage=usage,
            cost=CostEstimate(currency="USD", estimated=0.0),
            latency_ms=0,
            status="succeeded",
        )

        self._traces[trace_id] = TraceEvent(
            trace_id=trace_id,
            started_at=now,
            ended_at=now,
            caller=caller,
            route=route,
            events=[
                TraceStep(timestamp=now, name="route_selected", data=route.model_dump()),
                TraceStep(timestamp=now, name="provider_completed", data={"provider": route.selected.provider}),
            ],
            status="succeeded",
        )

    def get_usage(self, trace_id: str) -> UsageEvent:
        try:
            return self._usage[trace_id]
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=f"Usage not found for trace_id={trace_id}") from exc

    def get_trace(self, trace_id: str) -> TraceEvent:
        try:
            return self._traces[trace_id]
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=f"Trace not found for trace_id={trace_id}") from exc
