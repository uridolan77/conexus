from pydantic import BaseModel


class ConexusSettings(BaseModel):
    environment: str = "local"
    service_name: str = "conexus"
    contract_version: str = "1.0.0"
    routing_policy_path: str = "contracts/routing/default-policy.json"
    trace_sink: str = "memory"
    usage_sink: str = "memory"
