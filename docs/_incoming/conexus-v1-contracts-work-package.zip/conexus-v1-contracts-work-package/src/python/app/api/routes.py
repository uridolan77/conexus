from datetime import datetime, timezone
from fastapi import APIRouter

from app.domain.models import (
    ChatCompletionRequest,
    ChatCompletionResponse,
    ConexusMessage,
    EmbeddingRequest,
    EmbeddingResponse,
    HealthResponse,
    ModelListResponse,
    RouteDecision,
    RouteRequest,
    UsageEvent,
    TraceEvent,
)
from app.services.router import RoutingService
from app.services.providers import MockProvider
from app.services.tracing import TraceStore, make_trace_id

router = APIRouter()
routing_service = RoutingService()
provider = MockProvider()
trace_store = TraceStore()


@router.get("/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    return HealthResponse(status="ok", service="conexus", version="1.0.0")


@router.get("/v1/models", response_model=ModelListResponse)
async def list_models() -> ModelListResponse:
    return ModelListResponse(models=await provider.list_models())


@router.post("/v1/route", response_model=RouteDecision)
async def route(request: RouteRequest) -> RouteDecision:
    trace_id = request.trace_id or make_trace_id()
    return routing_service.route(request, trace_id=trace_id)


@router.post("/v1/chat/completions", response_model=ChatCompletionResponse)
async def chat_completion(request: ChatCompletionRequest) -> ChatCompletionResponse:
    trace_id = request.trace_id or make_trace_id()
    route_decision = routing_service.route(request.to_route_request(), trace_id=trace_id)
    response = await provider.chat(request, trace_id=trace_id, route=route_decision)
    trace_store.record_success(trace_id, request.caller, route_decision, response.usage)
    return response


@router.post("/v1/embeddings", response_model=EmbeddingResponse)
async def embeddings(request: EmbeddingRequest) -> EmbeddingResponse:
    trace_id = request.trace_id or make_trace_id()
    route_decision = routing_service.route(request.to_route_request(), trace_id=trace_id)
    response = await provider.embed(request, trace_id=trace_id, route=route_decision)
    trace_store.record_success(trace_id, request.caller, route_decision, response.usage)
    return response


@router.get("/v1/usage/{trace_id}", response_model=UsageEvent)
async def get_usage(trace_id: str) -> UsageEvent:
    return trace_store.get_usage(trace_id)


@router.get("/v1/traces/{trace_id}", response_model=TraceEvent)
async def get_trace(trace_id: str) -> TraceEvent:
    return trace_store.get_trace(trace_id)
