# Conexus v1 Needed Work

## Goal

Turn Conexus into the single LLM execution boundary for Agentor and Athanor.

Conexus should own:

- model provider calls
- model aliases
- routing decisions
- fallback policy
- prompt/runtime metadata
- cost accounting
- tracing
- usage events
- policy gates
- caching hooks
- evaluation hooks

Conexus should not own:

- agent workflow orchestration
- canonical knowledge state
- domain application logic
- Athanor provenance graph semantics
- Agentor task lifecycle semantics

## Workstream 1 — Contract foundation

### W1.1 Adopt OpenAPI contract

Use:

```text
contracts/openapi/conexus.v1.yaml
```

as the v1 source of truth.

Acceptance:

- OpenAPI file validates.
- Every implemented API route corresponds to an OpenAPI route.
- Request/response DTOs map directly to OpenAPI schemas.
- Breaking changes require a contract version bump or explicit ADR.

### W1.2 Add JSON schemas

Use JSON schemas for payload validation, examples, eval fixtures, and external clients.

Acceptance:

- `chat-request.schema.json` validates example chat requests.
- `chat-response.schema.json` validates example chat responses.
- `routing-policy.schema.json` validates routing policy files.
- `usage-event.schema.json` validates usage events.
- `trace-event.schema.json` validates trace events.

## Workstream 2 — Python Conexus API

### W2.1 FastAPI shell

Implement:

```text
GET  /health
GET  /v1/models
POST /v1/route
POST /v1/chat/completions
POST /v1/embeddings
GET  /v1/usage/{trace_id}
GET  /v1/traces/{trace_id}
```

Acceptance:

- API starts locally.
- `/health` returns service status.
- OpenAPI is exposed at FastAPI default docs.
- All route handlers return contract-shaped responses.

### W2.2 Provider abstraction

Implement a provider interface:

```python
class LlmProvider:
    async def chat(self, request: ChatRequest) -> ChatResponse: ...
    async def embed(self, request: EmbeddingRequest) -> EmbeddingResponse: ...
    async def list_models(self) -> list[ModelDescriptor]: ...
```

Acceptance:

- At least one mock provider exists.
- Real providers are isolated behind adapter classes.
- No route handler imports provider SDKs directly.

### W2.3 Routing engine

Implement routing as a deterministic service:

Inputs:

- requested task type
- model alias
- cost preference
- latency preference
- quality preference
- tenant/application
- optional required capabilities

Outputs:

- selected model
- selected provider
- reason codes
- fallback chain
- policy version

Acceptance:

- Same input + same policy version produces same route decision.
- Route decisions are traceable.
- The selected provider/model is recorded in every LLM response.

## Workstream 3 — Observability and accounting

### W3.1 Trace object

Every request should produce or propagate a `trace_id`.

Acceptance:

- If caller sends `trace_id`, Conexus uses it.
- If caller omits `trace_id`, Conexus creates it.
- Every response includes `trace_id`.
- Trace contains route decision, provider request metadata, provider response metadata, latency, and usage.

### W3.2 Usage object

Every provider call should produce a usage event.

Acceptance:

- Usage includes provider, model, prompt tokens, completion tokens, total tokens, estimated cost, latency, and caller metadata.
- Usage event is available through `/v1/usage/{trace_id}`.

## Workstream 4 — .NET client

### W4.1 Typed client

Implement a typed client package:

```text
src/dotnet/Conexus.Client
```

Acceptance:

- Agentor/Athanor can inject `IConexusClient`.
- Client exposes `CompleteAsync`, `EmbedAsync`, `RouteAsync`, `ListModelsAsync`.
- Client handles HTTP errors predictably.
- Client does not contain provider-specific logic.

### W4.2 Dependency injection extension

Add:

```csharp
services.AddConexusClient(options =>
{
    options.BaseUrl = "...";
    options.ApiKey = "...";
});
```

Acceptance:

- Usable from .NET Minimal API, Worker Service, and ASP.NET Core apps.

## Workstream 5 — Governance

### W5.1 Direct provider ban

Add a rule:

Agentor and Athanor must not call provider SDKs directly in normal operation.

Acceptance:

- Documented in ADR.
- Enforced in code review.
- Optional later: static scan for banned packages/namespaces.

### W5.2 Versioning

Adopt:

```text
/v1/...
```

for HTTP routes and:

```text
x-contract-version: 1.0.0
```

for API metadata.

Acceptance:

- Additive fields are allowed.
- Renames/removals require a version bump.
- Contract changes include example payload updates.
