# Cursor/Codex Prompt Series

Use these prompts one PR at a time.

## Prompt 1 — Adopt contracts and docs

You are working in the `conexus` repository. Add the contract-first file structure from this package. Do not implement business logic yet. Preserve the decision that Conexus remains Python/FastAPI for v1 and that .NET integration is provided through `Conexus.Client`.

Create or update:

- `contracts/openapi/conexus.v1.yaml`
- `contracts/json-schema/*.schema.json`
- `docs/adr/*.md`
- `docs/architecture/*.md`
- `examples/*`
- `README.md`

Acceptance: repository has a clear contract-first structure and a README that explains the boundary.

## Prompt 2 — Implement FastAPI shell

Implement the FastAPI shell for Conexus according to `contracts/openapi/conexus.v1.yaml`.

Required routes:

- `GET /health`
- `GET /v1/models`
- `POST /v1/route`
- `POST /v1/chat/completions`
- `POST /v1/embeddings`
- `GET /v1/usage/{trace_id}`
- `GET /v1/traces/{trace_id}`

Return contract-shaped mock responses only. Do not add real provider SDKs yet.

## Prompt 3 — Add Pydantic domain models

Create Pydantic models that mirror the OpenAPI schemas. Replace raw dict route responses with typed models. Keep names and fields aligned with the contract.

Acceptance: examples validate through Pydantic models and route responses are typed.

## Prompt 4 — Add provider abstraction and mock provider

Add a provider interface and deterministic mock provider. Route handlers must call the provider abstraction, not provider SDKs. Add error classes and normalized error response logic.

Acceptance: chat and embedding endpoints work with `MockProvider`.

## Prompt 5 — Add routing engine

Implement deterministic routing based on aliases, capabilities, and policy preferences. Add a simple default policy file. Return route reason codes and fallback chain.

Acceptance: same input and policy version returns same route decision.

## Prompt 6 — Add trace and usage events

Every request must include or generate a trace_id. Add JSONL sinks for trace and usage events. Implement usage/trace lookup endpoints.

Acceptance: every chat/embedding call writes trace and usage records.

## Prompt 7 — Add .NET Conexus.Client

Create a typed .NET client under `src/dotnet/Conexus.Client`.

Required:

- `IConexusClient`
- `ConexusClient`
- DTOs
- `AddConexusClient` DI extension
- README example

Do not put provider logic in the client.

## Prompt 8 — Add contract tests

Add tests that validate OpenAPI and JSON examples. Add Python tests for route shapes.

Acceptance: tests fail on schema drift.

## Prompt 9 — Add first real provider

Add the first real provider adapter behind the provider interface. Keep credentials only in Conexus settings. Normalize provider errors and usage.

Acceptance: a routing policy can select the provider and the response remains Conexus-shaped.

## Prompt 10 — Integrate Agentor/Athanor

Add documentation and examples showing Agentor and Athanor using `Conexus.Client`.

Important: do not introduce direct provider SDK calls in Agentor or Athanor.
