# PR-02 — FastAPI shell

## Goal

Create a minimal running Conexus API.

## Tasks

- Add `pyproject.toml`.
- Add `app/main.py`.
- Add route modules.
- Add `/health`.
- Add placeholder `/v1/models`.
- Add placeholder `/v1/route`.
- Add placeholder `/v1/chat/completions`.
- Add placeholder `/v1/embeddings`.

## Acceptance

- `uvicorn app.main:app --reload` starts.
- `/health` returns `ok`.
- Placeholder routes return contract-shaped mock responses.
