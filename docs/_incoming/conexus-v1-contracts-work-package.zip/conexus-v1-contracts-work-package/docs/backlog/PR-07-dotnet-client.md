# PR-07 — .NET Conexus.Client

## Goal

Provide typed .NET integration for Agentor and Athanor.

## Tasks

- Add `Conexus.Client.csproj`.
- Add `IConexusClient`.
- Add `ConexusClient`.
- Add request/response DTOs.
- Add DI extension.
- Add basic error handling.
- Add README usage examples.

## Acceptance

- .NET client can call health/models/route/chat/embeddings.
- No provider-specific logic exists in the client.
- Agentor/Athanor can inject the client with `IServiceCollection`.
