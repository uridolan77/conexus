# PR-08 — Contract tests

## Goal

Protect API/client compatibility.

## Tasks

- Add OpenAPI validation test.
- Add example payload validation.
- Add FastAPI route shape tests.
- Add .NET DTO compatibility notes.

## Acceptance

- Tests fail if OpenAPI is invalid.
- Tests fail if example payloads drift from schemas.
- Route responses match required contract fields.
