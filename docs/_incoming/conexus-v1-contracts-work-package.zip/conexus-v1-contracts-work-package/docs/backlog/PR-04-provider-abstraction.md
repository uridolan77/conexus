# PR-04 — Provider abstraction

## Goal

Add provider interface and deterministic mock provider.

## Tasks

- Create `LlmProvider` protocol/interface.
- Create `MockProvider`.
- Add provider registry.
- Add provider error classes.
- Add normalized error mapping.

## Acceptance

- Chat endpoint can call `MockProvider`.
- Embeddings endpoint can call `MockProvider`.
- Route handlers do not import real provider SDKs.
