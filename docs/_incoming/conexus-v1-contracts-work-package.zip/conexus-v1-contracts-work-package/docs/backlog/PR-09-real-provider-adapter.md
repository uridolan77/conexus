# PR-09 — First real provider adapter

## Goal

Add one production provider behind the provider abstraction.

## Tasks

- Add provider settings.
- Add first real provider adapter.
- Map Conexus request to provider request.
- Map provider response to Conexus response.
- Extract usage.
- Normalize errors.
- Add retries only at provider boundary.

## Acceptance

- Real provider can be selected by routing policy.
- Provider errors become normalized Conexus errors.
- Usage data is captured.
