# PR-06 — Tracing and usage

## Goal

Make every call traceable.

## Tasks

- Add trace ID middleware/helper.
- Add usage event model.
- Add JSONL usage sink.
- Add JSONL trace sink.
- Add `/v1/usage/{trace_id}`.
- Add `/v1/traces/{trace_id}`.

## Acceptance

- Every chat/embedding response includes `trace_id`.
- Usage event is written for every call.
- Trace can be retrieved by trace_id.
