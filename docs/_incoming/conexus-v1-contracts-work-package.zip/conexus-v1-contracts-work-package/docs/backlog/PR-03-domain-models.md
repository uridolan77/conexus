# PR-03 — Domain models

## Goal

Add Pydantic models matching the OpenAPI contract.

## Tasks

- Add request/response models for chat.
- Add request/response models for embeddings.
- Add model descriptor.
- Add route decision models.
- Add usage and trace models.
- Add normalized error model.

## Acceptance

- Route handlers use domain models.
- Example JSON payloads validate against Pydantic models.
- Names align with OpenAPI schemas.
