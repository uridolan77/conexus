# PR-01 — Repository foundation and contract adoption

## Goal

Install the contract-first structure and make Conexus ready for incremental implementation.

## Tasks

- Add `/contracts/openapi/conexus.v1.yaml`.
- Add `/contracts/json-schema`.
- Add `/docs/adr`.
- Add `/docs/architecture`.
- Add `/examples`.
- Add `/tests/contract-tests`.
- Add changelog stub.
- Add README section declaring Conexus as Python/FastAPI gateway.

## Acceptance

- File structure exists.
- README explains the Python Conexus / .NET client boundary.
- No application logic is added yet.
