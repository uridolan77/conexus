# PR-10 — Agentor/Athanor integration pattern

## Goal

Define how .NET systems consume Conexus.

## Tasks

- Add example Agentor registration.
- Add example Athanor registration.
- Add direct-provider-ban note.
- Add sample `appsettings.json`.
- Add typed client usage examples.

## Acceptance

- Agentor can request chat completion through `IConexusClient`.
- Athanor can request canonicalization/extraction through `IConexusClient`.
- No provider credentials are needed outside Conexus.
