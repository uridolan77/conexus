# PR-05 — Routing engine

## Goal

Implement deterministic routing decisions.

## Tasks

- Add routing policy model.
- Add default routing policy file.
- Implement alias resolution.
- Implement required capability filtering.
- Implement fallback chain output.
- Return route reason codes.

## Acceptance

- `/v1/route` returns a route decision.
- `/v1/chat/completions` records selected provider/model.
- Same inputs produce same output for same policy version.
