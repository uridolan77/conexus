# Provider Abstraction

## Provider interface

The provider abstraction should hide provider-specific SDK/API details from route handlers.

```python
class LlmProvider:
    name: str

    async def chat(self, request: ChatRequest) -> ChatResponse:
        ...

    async def embed(self, request: EmbeddingRequest) -> EmbeddingResponse:
        ...

    async def list_models(self) -> list[ModelDescriptor]:
        ...
```

## Provider adapter responsibilities

Provider adapters should handle:

- provider request transformation
- provider response transformation
- token usage extraction
- error normalization
- retryable error classification
- streaming translation, later
- cost estimate hooks

Provider adapters should not handle:

- business workflow logic
- agent planning
- Athanor provenance semantics
- global routing policy

## Minimum adapters for v1

Start with:

1. `MockProvider` for deterministic tests.
2. `OpenAIProvider` or whichever provider you currently use first.
3. Optional `AnthropicProvider` once routing/fallback is ready.

## Normalized provider error

All provider errors should become:

```json
{
  "error": {
    "code": "provider_rate_limited",
    "message": "Provider rate limit exceeded.",
    "provider": "openai",
    "retryable": true,
    "trace_id": "..."
  }
}
```
