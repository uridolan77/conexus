# Observability and Cost Accounting

## Required per-call data

Every LLM call should record:

- trace_id
- caller system
- caller component
- operation
- provider
- model
- model alias
- route decision
- start time
- end time
- latency_ms
- prompt/input tokens
- completion/output tokens
- total tokens
- estimated cost
- status
- normalized error, if any

## Storage for v1

For v1, storage can be simple:

- in-memory for local development
- JSONL file for local persistence
- later: Postgres, ClickHouse, or OpenTelemetry pipeline

## Do not overbuild immediately

Do not build a full observability platform before the contract and gateway work.

Start with:

```text
trace_id in every response
structured logs
usage endpoint by trace_id
JSONL sink
```

## Example usage event

```json
{
  "trace_id": "trc_01J...",
  "timestamp": "2026-05-11T08:00:00Z",
  "caller": {
    "system": "agentor",
    "component": "planner",
    "operation": "create_plan"
  },
  "provider": "openai",
  "model": "gpt-4.1-mini",
  "model_alias": "fast-general",
  "usage": {
    "input_tokens": 1200,
    "output_tokens": 500,
    "total_tokens": 1700
  },
  "cost": {
    "currency": "USD",
    "estimated": 0.0017
  },
  "latency_ms": 1310,
  "status": "succeeded"
}
```
