# Routing Policy

## Purpose

Routing decides which provider/model should handle a request.

## Inputs

- requested model alias
- task type
- required capabilities
- caller system/component
- quality preference
- latency preference
- cost preference
- policy hints
- tenant/environment
- previous provider health
- fallback eligibility

## Outputs

- provider
- model
- model alias
- reason codes
- fallback chain
- policy version

## Example route decision

```json
{
  "trace_id": "trc_01J...",
  "selected": {
    "provider": "openai",
    "model": "gpt-4.1-mini",
    "model_alias": "fast-general"
  },
  "reason_codes": [
    "alias_match",
    "cost_preference_balanced",
    "capability_text_generation"
  ],
  "fallback_chain": [
    { "provider": "anthropic", "model": "claude-3-5-haiku-latest" }
  ],
  "policy_version": "2026-05-11.1"
}
```

## Determinism rule

Given the same request, same policy version, and same provider health snapshot, routing should return the same decision.

## Route reason code examples

- `alias_match`
- `capability_text_generation`
- `capability_embedding`
- `quality_preference_high`
- `latency_preference_low`
- `cost_preference_low`
- `provider_health_ok`
- `fallback_available`
- `policy_override`
- `tenant_restriction`
