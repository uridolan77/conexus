# Runtime Boundary

## Overview

Conexus is an LLM gateway. It is not an agent framework and not a knowledge engine.

```text
+-----------------+       +------------------+       +--------------------+
| Agentor (.NET)  | ----> | Conexus.Client   | ----> | Conexus API        |
+-----------------+       +------------------+       | Python/FastAPI     |
                                                       +---------+----------+
+-----------------+       +------------------+                 |
| Athanor (.NET)  | ----> | Conexus.Client   |                 v
+-----------------+       +------------------+       +--------------------+
                                                       | LLM Providers       |
                                                       +--------------------+
```

## Why this boundary matters

The LLM boundary is where provider complexity, cost, policy, and observability converge. It should not be scattered across the application layer.

## Required invariants

1. No direct provider calls from Agentor/Athanor.
2. All LLM calls return `trace_id`.
3. All route decisions are explicit.
4. Provider errors are normalized.
5. Cost and token usage are captured.
6. Model aliases are resolved only by Conexus.
