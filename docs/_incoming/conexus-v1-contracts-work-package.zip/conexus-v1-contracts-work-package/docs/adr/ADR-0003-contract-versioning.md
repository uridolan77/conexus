# ADR-0003: Contract versioning policy

## Status

Proposed.

## Decision

Conexus HTTP routes use major API versions:

```text
/v1/...
```

The OpenAPI contract carries semantic contract version metadata:

```yaml
info:
  version: 1.0.0
```

## Compatibility rules

Compatible changes:

- adding optional request fields
- adding response fields
- adding new endpoints
- adding enum values only when clients are resilient to unknown values

Breaking changes:

- removing fields
- renaming fields
- changing field meaning
- changing requiredness
- changing error shape
- changing route behavior in a way that breaks existing clients

## Required process

Every contract change must update:

- OpenAPI
- JSON schemas, where relevant
- examples
- .NET DTOs or generator output
- contract tests
- changelog
