# ADR-0004: Trace and usage ownership

## Status

Proposed.

## Decision

Conexus owns trace and usage events for all LLM calls.

Callers may provide:

- `trace_id`
- `caller.system`
- `caller.component`
- `caller.operation`
- `caller.user_id`
- `metadata`

Conexus adds:

- selected provider
- selected model
- route decision
- route policy version
- fallback events
- token usage
- cost estimate
- latency
- provider status
- normalized error shape

## Rationale

Agentor and Athanor need end-to-end accountability. Provider logs alone are insufficient. Application logs alone are insufficient. Conexus is the only service that sees routing intent, provider execution, normalized result, and cost.

## Acceptance

Every successful or failed LLM call produces a trace record.
