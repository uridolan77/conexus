# ADR-0002: Conexus is the single LLM execution boundary

## Status

Accepted.

## Context

Agentor and Athanor both need LLM capabilities. If each service calls providers directly, the system loses control over costs, routing, policy, tracing, prompt versions, and fallback behavior.

## Decision

All normal LLM calls go through Conexus.

Agentor and Athanor must not call provider SDKs directly except in explicitly marked local test fixtures.

## Boundary

```text
Agentor -> Conexus.Client -> Conexus API -> Provider
Athanor -> Conexus.Client -> Conexus API -> Provider
```

## Conexus owns

- provider credentials
- provider adapters
- model aliases
- routing
- fallback chains
- prompt/runtime metadata
- tracing
- usage and cost accounting
- provider error normalization
- policy checks

## Agentor owns

- task planning
- agent workflows
- tool execution
- human-in-the-loop transitions
- agent state

## Athanor owns

- canonical knowledge state
- provenance
- claim/entity/artifact semantics
- decision reconstruction
- state inspection dashboard

## Consequences

This creates a single source of truth for LLM execution and makes cross-system observability possible.
