# Decision Summary

## D1 — Keep Conexus in Python for v1

Conexus remains Python/FastAPI because the LLM provider and experimentation ecosystem moves fastest there, and there is already existing Python gateway/router work.

## D2 — Do not build a second Conexus in .NET

A .NET rewrite would duplicate provider behavior, routing rules, traces, cost accounting, fallback behavior, and prompt/runtime logic.

## D3 — Make .NET integration first-class through a client library

Agentor and Athanor should use a typed .NET client, not direct provider SDKs.

## D4 — Contract first

OpenAPI and JSON schemas define the boundary. Implementation follows contracts, not the other way around.

## D5 — Conexus owns execution, not orchestration

Conexus routes and executes LLM calls. Agentor orchestrates agents. Athanor canonicalizes knowledge/provenance/state.

## D6 — Every call is traceable

No LLM request should be invisible. Every call should carry `trace_id`, selected provider/model, route reason, usage, latency, and caller metadata.
