# Conexus v1 Contracts & Work Package

This package defines the next work needed for **Conexus** as the LLM router/gateway used by **Agentor** and **Athanor**.

## Core decision

Conexus remains a **Python/FastAPI service** for v1.

Agentor and Athanor remain **.NET systems** and integrate through a typed .NET client generated or maintained from the Conexus OpenAPI contract.

There should be no parallel `.NET Conexus` implementation during v1.

## Package contents

```text
contracts/
  openapi/conexus.v1.yaml
  json-schema/*.schema.json

docs/
  adr/*.md
  architecture/*.md
  backlog/*.md
  prompts/*.md

src/
  dotnet/Conexus.Client/
  python/app/

tests/
  contract-tests/

examples/
  requests/
  responses/
```

## Intended repository placement

Recommended placement in the `conexus` repo:

```text
/conexus
  /contracts
  /docs
  /src/python
  /src/dotnet/Conexus.Client
  /tests
  /examples
```

Later, the .NET client can be copied or published for use by:

```text
/agentor
/athanor
```

## Non-negotiable boundary

Agentor and Athanor should not call OpenAI, Anthropic, Gemini, local models, or any other provider directly during normal operation.

They call:

```text
Agentor/Athanor -> Conexus.Client -> Conexus API -> Provider
```

## First implementation sequence

1. Adopt `contracts/openapi/conexus.v1.yaml` as the source of truth.
2. Add the Python FastAPI skeleton.
3. Implement health, models, route, chat, and embeddings.
4. Add provider adapters behind a provider interface.
5. Add tracing and usage events.
6. Add the .NET `Conexus.Client`.
7. Add contract tests.
8. Block direct provider calls from Agentor/Athanor by convention and code review.
