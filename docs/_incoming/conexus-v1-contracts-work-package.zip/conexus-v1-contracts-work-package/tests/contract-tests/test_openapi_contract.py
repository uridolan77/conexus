from pathlib import Path
import json

import yaml
from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[2]


def test_openapi_contract_parses():
    path = ROOT / "contracts" / "openapi" / "conexus.v1.yaml"
    data = yaml.safe_load(path.read_text(encoding="utf-8"))

    assert data["openapi"].startswith("3.")
    assert data["info"]["title"] == "Conexus API"
    assert "/v1/chat/completions" in data["paths"]
    assert "/v1/embeddings" in data["paths"]
    assert "/v1/route" in data["paths"]


def test_chat_request_example_validates():
    schema_path = ROOT / "contracts" / "json-schema" / "chat-request.schema.json"
    example_path = ROOT / "examples" / "requests" / "chat.simple.json"

    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    example = json.loads(example_path.read_text(encoding="utf-8"))

    Draft202012Validator.check_schema(schema)
    Draft202012Validator(schema).validate(example)


def test_chat_response_example_validates():
    schema_path = ROOT / "contracts" / "json-schema" / "chat-response.schema.json"
    example_path = ROOT / "examples" / "responses" / "chat.simple.response.json"

    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    example = json.loads(example_path.read_text(encoding="utf-8"))

    Draft202012Validator.check_schema(schema)
    Draft202012Validator(schema).validate(example)
