# Contract Tests

The goal of contract tests is to prevent drift between:

- OpenAPI contract
- JSON schemas
- examples
- Python API models
- .NET DTOs

Start simple.

Recommended checks:

1. OpenAPI file parses.
2. JSON schemas parse.
3. Example requests validate against JSON schemas.
4. Example responses validate against JSON schemas.
5. Python route responses include required fields.
6. .NET DTOs are updated whenever OpenAPI changes.
